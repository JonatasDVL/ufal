public class Operacao {

  public void calcular(float num1, float num2){
    System.out.println("Operação");
  };
  
}
